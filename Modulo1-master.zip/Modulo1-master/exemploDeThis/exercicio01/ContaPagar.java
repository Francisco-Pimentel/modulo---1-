package orientacao_a_objetos_2_objeto_this.exemploDeThis.exercicio01;

public class ContaPagar {

    String Descricao;
    Double valor;
    String DataVencimento;
    Fornecedor imobiliaria;
    String Fornecedor;

}

