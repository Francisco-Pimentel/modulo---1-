package orientacao_a_objetos_2_objeto_this.exemploDeThis.exercicio01;

public class Fornecedor {
    String nome;
    String Fornecedor;



    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
