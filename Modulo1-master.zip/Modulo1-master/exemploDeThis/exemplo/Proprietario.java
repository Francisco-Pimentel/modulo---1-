package orientacao_a_objetos_2_objeto_this.exemploDeThis.exemplo;

public class Proprietario {
    String nome;
    String cpf;
    int idade;
    String logradouro;
    String bairro;
    String cidade;
}
