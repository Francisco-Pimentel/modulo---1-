package orientacao_a_objetos_2_objeto_this.exemploDeThis.construtores;

public class TesteConstrutor {
    public static void main(String[] args) {
        Pessoa pessoa = new Pessoa("João");
        Pessoa pessoa1 = new Pessoa("Maria" , 22);
    }
}
