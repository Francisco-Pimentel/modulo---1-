package com.company.chesco;

import java.util.Scanner;

public class aposentadoria {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

    }
}
