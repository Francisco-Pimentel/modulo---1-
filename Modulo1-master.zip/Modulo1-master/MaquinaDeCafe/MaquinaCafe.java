package orientacao_a_objetos_2_objeto_this.exercicio03;

public class MaquinaCafe {
    public Double acucarDisponivel = 200d;

    public void fazerCafe(int acucar) {
        this.acucarDisponivel = acucarDisponivel;
        System.out.println("Está sendo preparado com "+ acucar +" gramas de açucar");

    }
    public void fazerCafe(){
        System.out.println("Fazendo café com 10 gramas de açucar");

    }
    public void fazerCafe(){

    }


    }

