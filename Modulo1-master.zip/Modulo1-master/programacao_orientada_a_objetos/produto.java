package programacao_orientada_a_objetos;

public class produto {

   String nome;

   Double precoUnitario;

   Integer quantidade;
}
