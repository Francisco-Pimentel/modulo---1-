package programacao_orientada_a_objetos.exercicio01;

public class Estoque {

   static final Integer Quantidade_minima_estoque = 10;


    String nome;

    Integer quantidadeEstoque ;



}
