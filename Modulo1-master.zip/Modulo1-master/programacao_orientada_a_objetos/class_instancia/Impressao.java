package programacao_orientada_a_objetos.class_instancia;

public class Impressao {
    public static void informacao(String texto) {
        System.out.println("[Info]" + texto);

    }
}
