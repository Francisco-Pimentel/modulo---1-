package programacao_orientada_a_objetos.class_instancia;

public class Produto {

    public static Integer quantidadeMinimaEstoque = 1 ;
    public String nome;
}
