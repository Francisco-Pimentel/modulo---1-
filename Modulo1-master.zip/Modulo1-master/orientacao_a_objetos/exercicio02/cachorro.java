package orientacao_a_objetos.exercicio02;

public class cachorro {
    String nome;
    Humano dono;
}
