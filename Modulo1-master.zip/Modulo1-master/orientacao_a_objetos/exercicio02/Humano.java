package orientacao_a_objetos.exercicio02;

public class Humano {
    String nome;


}
