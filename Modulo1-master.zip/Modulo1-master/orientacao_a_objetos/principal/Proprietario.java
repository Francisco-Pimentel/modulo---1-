package orientacao_a_objetos.principal;

public class Proprietario {
    String nome;
    String cpf;
    int idade;
    String logradouro;
    String bairro;
    String cidade;
}
