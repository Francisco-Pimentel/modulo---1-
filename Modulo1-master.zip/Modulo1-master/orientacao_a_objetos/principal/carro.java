package orientacao_a_objetos.principal;

public class carro {
    String fabricantes;
    String modelo;
    String cor;
    int anoDeFabricacao;
    Proprietario dono;

}


