package orientacao_a_objetos.exercicio03;

public class produto {
    String descricao;
    int quantidade;

    // void para acompanhar o metodo.
    void descrever(){
        System.out.println(descricao + " - " + quantidade + " itens");
    }
}
