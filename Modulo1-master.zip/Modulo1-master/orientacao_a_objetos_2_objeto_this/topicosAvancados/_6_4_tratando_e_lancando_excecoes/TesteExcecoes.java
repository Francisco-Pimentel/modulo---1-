package orientacao_a_objetos_2_objeto_this.topicosAvancados._6_4_tratando_e_lancando_excecoes;

import java.util.Locale;

public class TesteExcecoes {
    public static void main(String[] args) {
        //int numero = 5 / 0;
        String s = null;
        String maiuscula = s.toUpperCase();


        /*ContaCorrente cc = new ContaCorrente(100);

        try {
            cc.depositar(-10);
        } catch (IllegalArgumentException e) {
            System.out.println("Você executou uma operação ilegal: " + e.getMessage());
        }*/
    }


}
