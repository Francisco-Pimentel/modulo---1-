package orientacao_a_objetos_2_objeto_this.topicosAvancados._6_4_tratando_e_lancando_excecoes;

public class SaldoInsuficienteException extends Exception {

    public SaldoInsuficienteException(String mensagem) {
        super(mensagem);
    }
}
