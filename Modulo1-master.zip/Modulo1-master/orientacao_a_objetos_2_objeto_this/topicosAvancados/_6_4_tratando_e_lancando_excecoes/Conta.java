package orientacao_a_objetos_2_objeto_this.topicosAvancados._6_4_tratando_e_lancando_excecoes;

public class Conta {

    protected double saldo;

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
}
