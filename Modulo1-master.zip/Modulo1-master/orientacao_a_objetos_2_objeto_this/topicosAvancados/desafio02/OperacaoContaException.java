package orientacao_a_objetos_2_objeto_this.topicosAvancados.desafio02;

public class OperacaoContaException extends Exception {

	public OperacaoContaException(String msg) {
		super(msg);
	}

}
