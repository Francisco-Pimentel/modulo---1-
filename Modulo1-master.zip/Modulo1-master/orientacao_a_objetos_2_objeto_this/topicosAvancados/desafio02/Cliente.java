package orientacao_a_objetos_2_objeto_this.topicosAvancados.desafio02;

public class Cliente extends pessoa {

}
