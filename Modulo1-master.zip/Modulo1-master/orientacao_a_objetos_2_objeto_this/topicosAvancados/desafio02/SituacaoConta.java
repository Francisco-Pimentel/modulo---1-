package orientacao_a_objetos_2_objeto_this.topicosAvancados.desafio02;

public enum SituacaoConta {
    PENDENTE(), PAGA(), CANCELADA();




}
