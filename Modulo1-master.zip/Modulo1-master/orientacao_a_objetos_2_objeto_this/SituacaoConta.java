package orientacao_a_objetos_2_objeto_this.exercicio01;

public enum SituacaoConta {
    PENDENTE(), PAGA(), CANCELADA();




}
