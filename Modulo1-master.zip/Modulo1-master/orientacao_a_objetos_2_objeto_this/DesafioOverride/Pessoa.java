package orientacao_a_objetos_2_objeto_this.DesafioOverride;
public abstract class Pessoa {
        public String nome;
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
}
