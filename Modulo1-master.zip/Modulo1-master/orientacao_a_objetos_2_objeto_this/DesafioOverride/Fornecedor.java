package orientacao_a_objetos_2_objeto_this.DesafioOverride;

public class Fornecedor extends Pessoa {
}
