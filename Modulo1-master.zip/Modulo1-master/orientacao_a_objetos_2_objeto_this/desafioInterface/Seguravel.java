package orientacao_a_objetos_2_objeto_this.desafioInterface;

public interface Seguravel {
   public String obterDescricao();
    public double calcularValorApolice();

}
