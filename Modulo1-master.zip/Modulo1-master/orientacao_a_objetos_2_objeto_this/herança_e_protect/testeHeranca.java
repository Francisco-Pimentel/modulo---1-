package orientacao_a_objetos_2_objeto_this.herança_e_protect;


    public class testeHeranca {
        public static void main(String[] args) {
            Jogador j = new Jogador();
            j.nome = "Ronaldo";
            j.idade = 33;
            j.seApresentar();
            j.dizerSeAindaJoga();
        }
    }

