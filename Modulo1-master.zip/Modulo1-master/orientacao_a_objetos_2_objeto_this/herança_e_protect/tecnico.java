package orientacao_a_objetos_2_objeto_this.herança_e_protect;

public class tecnico extends pessoa {
    }

