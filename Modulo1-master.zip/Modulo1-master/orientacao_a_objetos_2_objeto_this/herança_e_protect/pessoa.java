package orientacao_a_objetos_2_objeto_this.herança_e_protect;

public class pessoa {
    String nome;
    protected int idade;
    public void seApresentar(){
        System.out.println("Olá, eu sou " + nome +
                ", e tenho " + idade + "anos.");
        }
    }

