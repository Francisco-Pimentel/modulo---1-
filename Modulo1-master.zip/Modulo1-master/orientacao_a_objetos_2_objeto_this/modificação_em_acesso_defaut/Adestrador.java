package orientacao_a_objetos_2_objeto_this.modificação_em_acesso_defaut;

public class Adestrador {
    void ensinarCachorrosSentar(Cachorro cachorro){
        cachorro.sentar();
    }
}
