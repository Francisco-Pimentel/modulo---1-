package orientacao_a_objetos_2_objeto_this.enumerações;

public class TesteEnum {
    public static void main(String[] args) {
        carta quatroPaus = new carta(4, naipe.PAUS);
        quatroPaus.imprimirCarta();
    }
}
