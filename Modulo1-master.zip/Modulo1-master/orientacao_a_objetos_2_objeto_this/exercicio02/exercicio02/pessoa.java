package orientacao_a_objetos_2_objeto_this.exercicio02;

public class pessoa {
    String nome;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
