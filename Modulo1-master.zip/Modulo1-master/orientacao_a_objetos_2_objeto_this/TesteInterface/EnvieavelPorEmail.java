package orientacao_a_objetos_2_objeto_this.TesteInterface;

public interface EnvieavelPorEmail {
    void enviar(String email);
}
