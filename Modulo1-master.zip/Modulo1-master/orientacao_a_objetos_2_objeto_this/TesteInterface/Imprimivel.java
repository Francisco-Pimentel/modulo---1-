package orientacao_a_objetos_2_objeto_this.TesteInterface;


// O INTERFACE SERVE PARA QUE VC POSSA DETERMINAR COMPORTAMENTOS QUE VC NÃO QUER QUE FIQUEM EXCLUSIVOS A UMA UNICA CLASSE.
public interface Imprimivel {
    void imprimir();


}
